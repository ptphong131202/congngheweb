<?php

require '../bootstrap.php';

use App\Models\Book;

render_view_twig('twig/books.twig', [
	'books' => Book::all()
]);
