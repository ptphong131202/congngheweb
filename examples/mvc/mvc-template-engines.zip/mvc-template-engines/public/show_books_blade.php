<?php

require '../bootstrap.php';

use App\Models\Book;

render_view_blade('blade.books', [
    'books' => Book::all()
]);
