<?php

require '../bootstrap.php';

use App\Models\Book;

render_view('php/books', [
    'books' => Book::all()
]);
