<?php

function redirect(string $path)
{
	header('Location: ' . $path);
	exit;
}

function render_view(string $document, array $data = [])
{
	$path = VIEWS_DIR . "/{$document}.php";
	extract($data, EXTR_PREFIX_SAME, '__var_');
	require($path);
}

$twig = new \Twig\Environment(
	new \Twig\Loader\FilesystemLoader(VIEWS_DIR)
);
function render_view_twig(string $document, array $data = [])
{
	global $twig;
	echo $twig->render($document, $data);
}


$blade = new \eftec\bladeone\BladeOne(VIEWS_DIR, CACHE_DIR);
function render_view_blade(string $document, array $data = [])
{
	global $blade;
	echo $blade->run($document, $data);
}
