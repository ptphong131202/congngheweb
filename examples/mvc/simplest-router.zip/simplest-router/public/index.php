<?php

define('ROOT_DIR', dirname(__DIR__));

$request = $_SERVER['REQUEST_URI'];

switch ($request) {
    case '/':
    case '/home.php':
        require ROOT_DIR . '/views/home.php';
        break;
    case '/about.php':
        require ROOT_DIR . '/views/about.php';
        break;
    default:
        http_response_code(404);
        require ROOT_DIR . '/views/404.php';
        break;
}
