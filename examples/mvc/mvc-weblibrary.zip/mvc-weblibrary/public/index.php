<?php

require __DIR__ . '/../bootstrap.php';

$router = new AltoRouter();

$router->map(
	'GET',
	'/login',
	[App\Controllers\AuthController::class, 'showLoginForm'],
	'login.show'
);

$router->map(
	'POST',
	'/login',
	[App\Controllers\AuthController::class, 'login'],
	'login.post'
);

$router->map(
	'GET',
	'/',
	[App\Controllers\BookController::class, 'index'],
	'books.show'
);

$router->map(
	'GET',
	'/user/[a:username]',
	[App\Controllers\UserController::class, 'index'],
	'user.show'
);

$router->map(
	'GET',
	'/borrow/[i:bookId]',
	[App\Controllers\UserController::class, 'borrow'],
	'user.borrow'
);

$router->map(
	'GET',
	'/return/[i:bookId]',
	[App\Controllers\UserController::class, 'return'],
	'user.return'
);

$router->map(
	'GET',
	'/logout',
	[App\Controllers\AuthController::class, 'logout'],
	'logout'
);

$match = $router->match();

if ($match === false) {
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
	exit('404 Not Found');
}

if (is_callable($match['target'])) {
	call_user_func_array($match['target'], $match['params']);
} elseif (is_array($match['target'])) {
	$controller = new $match['target'][0]();
	$action = $match['target'][1];
	if (is_callable([$controller, $action])) {
		call_user_func_array([$controller, $action], $match['params']);
	} else {
		header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error');
		exit('500 Internal Server Error');
	}
}
