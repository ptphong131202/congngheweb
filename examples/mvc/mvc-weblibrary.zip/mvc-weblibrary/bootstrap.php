<?php

define('VIEWS_DIR', __DIR__ . '/src/views');
session_start();

require 'vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$databaseManager = new Illuminate\Database\Capsule\Manager();
$databaseManager->addConnection([
	'driver' => 'mysql',
	'host' => $_ENV['DB_HOST'],
	'database' => $_ENV['DB_NAME'],
	'username' => $_ENV['DB_USER'],
	'password' => $_ENV['DB_PASS'],
]);

$databaseManager->setAsGlobal();
$databaseManager->bootEloquent();
