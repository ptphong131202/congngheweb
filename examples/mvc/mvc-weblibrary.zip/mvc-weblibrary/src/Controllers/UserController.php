<?php

namespace App\Controllers;

use App\Models\User;

class UserController
{
	public function index($username)
	{
		render_view('userhome', [
			'user' => User::where('name', $username)->with('books')->first(),
			'router' => router()
		]);
	}

	public function borrow($bookId)
	{
		User::where('name', $_SESSION['user'])
			->first()
			->borrow($bookId);

		redirect(
			router()->generate(
				'user.show',
				['username' => $_SESSION['user']]
			)
		);
	}

	public function return($bookId)
	{
		User::where('name', $_SESSION['user'])
			->first()
			->return($bookId);

		redirect(
			router()->generate(
				'user.show',
				['username' => $_SESSION['user']]
			)
		);
	}
}
