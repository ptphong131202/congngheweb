<?php

namespace App\Controllers;

class AuthController
{
	public function showLoginForm()
	{
		render_view('login', [
			'router' => router()
		]);
	}

	public function login()
	{
		$_SESSION['user'] = $_POST['username'];
		redirect(
			router()->generate(
				'user.show',
				['username' => $_SESSION['user']]
			)
		);
	}

	public function logout()
	{
		unset($_SESSION['user']);
		redirect('/');
	}
}
