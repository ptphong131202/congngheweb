<?php

namespace App\Controllers;

use App\Models\Book;

class BookController
{
    public function index()
    {
        render_view('libhome', [
            'books' => Book::orderBy('title')->get(),
            'router' => router()
        ]);
    }
}
