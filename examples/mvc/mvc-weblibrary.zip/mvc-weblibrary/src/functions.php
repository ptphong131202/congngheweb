<?php

function redirect($path): void
{
	header('Location: ' . $path);
	exit;
}

function render_view(string $document, array $vars = []): void
{
	$path = VIEWS_DIR . "/{$document}.php";
	extract($vars, EXTR_PREFIX_SAME, '__var_');
	require($path);
}

function router(): AltoRouter
{
	global $router;
	return $router;
}
