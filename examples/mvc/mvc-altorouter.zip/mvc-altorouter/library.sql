-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2022 at 06:45 AM
-- Server version: 10.6.4-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `binding` enum('paper','cloth') NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `title`, `binding`, `quantity`) VALUES
(1, 'Java in a Nutshell', 'paper', 1),
(2, 'Programming Perl', 'cloth', 2),
(3, 'Multimedia Systems', 'paper', 6),
(4, 'Data Structures in Java', 'paper', 3),
(5, 'Java Foundation Classes', 'paper', 1),
(6, 'Java Swing', 'paper', 2),
(7, 'Php in Action', 'cloth', 5),
(8, 'jQuery Cookbook', 'cloth', 4),
(9, 'Introduction to the Theory of Computation', 'cloth', 3),
(10, 'Artificial Intelligence: A Modern Approach', 'paper', 0),
(11, 'Introduction to Algorithms', 'cloth', 1),
(12, 'The C Programming Language', 'paper', 5),
(13, 'A Discipline of Programming', 'paper', 1),
(14, 'Computability and Logic', 'paper', 5),
(15, 'The Psychology of Computer Programming', 'paper', 3),
(16, 'Design and Validation of Computer Protocols', 'cloth', 4),
(17, 'Computational Complexity', 'paper', 2),
(18, 'Computability and Unsolvability', 'paper', 2),
(19, 'Database System Concepts', 'cloth', 0),
(20, 'Structured Computer Organization', 'paper', 5),
(21, 'Modern Operating Systems', 'cloth', 0),
(22, 'Distributed Operating Systems', 'paper', 6),
(23, 'The Mythical Man Month', 'cloth', 3),
(24, 'More Programming Pearls', 'paper', 0),
(25, 'Art of Computer Programming', 'cloth', 1),
(26, 'Machine learning', 'paper', 0),
(27, 'High Performance Computing', 'paper', 0),
(28, 'Linux Programming Bible', 'paper', 4),
(29, 'Real-Time Concepts for Embedded Systems', 'cloth', 3),
(30, 'Advanced Compiler Design and Implementation', 'paper', 5),
(31, 'Computer Networks', 'cloth', 2),
(32, 'Crafting a Compiler with C', 'paper', 0),
(33, 'UNIX Internals: The New Frontiers', 'paper', 2),
(34, 'Understanding the Linux Kernel', 'paper', 0);

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `borrowed_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`id`, `book_id`, `user_id`, `borrowed_at`) VALUES
(1, 1, 2, '2022-02-03'),
(2, 1, 3, '2022-01-23'),
(3, 2, 3, '2022-02-23'),
(4, 4, 6, '2022-03-17'),
(5, 5, 5, '2022-02-01'),
(6, 6, 2, '2022-01-30'),
(7, 6, 5, '2022-02-21'),
(8, 7, 2, '2022-03-14'),
(9, 8, 3, '2022-02-22'),
(10, 8, 6, '2022-02-19'),
(11, 9, 1, '2022-02-08'),
(12, 9, 6, '2022-03-07'),
(13, 10, 1, '2022-03-09'),
(14, 11, 1, '2022-01-28'),
(15, 11, 6, '2022-02-25'),
(16, 12, 2, '2022-02-13'),
(17, 13, 2, '2022-03-01'),
(18, 13, 5, '2022-01-29'),
(19, 13, 6, '2022-02-11'),
(20, 14, 6, '2022-02-09'),
(21, 15, 3, '2022-02-07'),
(22, 15, 5, '2022-02-08'),
(23, 16, 4, '2022-01-30'),
(24, 17, 1, '2022-02-07'),
(25, 17, 2, '2022-03-10'),
(26, 18, 3, '2022-03-01'),
(27, 18, 4, '2022-02-02'),
(28, 18, 5, '2022-02-12'),
(29, 19, 2, '2022-02-19'),
(30, 19, 4, '2022-03-16'),
(31, 20, 5, '2022-01-21'),
(32, 21, 6, '2022-03-09'),
(33, 23, 2, '2022-02-27'),
(34, 24, 1, '2022-02-12'),
(35, 24, 5, '2022-03-21'),
(36, 25, 6, '2022-03-03'),
(37, 26, 1, '2022-02-12'),
(38, 26, 4, '2022-01-24'),
(39, 27, 3, '2022-01-22'),
(40, 28, 6, '2022-01-27'),
(41, 29, 5, '2022-02-04'),
(42, 29, 6, '2022-02-14'),
(43, 30, 6, '2022-03-11'),
(44, 31, 4, '2022-01-30'),
(45, 31, 6, '2022-01-25'),
(46, 32, 1, '2022-02-15'),
(47, 33, 5, '2022-03-15'),
(48, 34, 4, '2022-02-16'),
(54, 3, 6, '2022-02-26');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` char(64) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `is_admin`) VALUES
(1, 'john', 'arachnid@oracle.com', '96d9632f363564cc3032521409cf22a852f2032eec099ed5967c0d000cec607a', 0),
(2, 'kirsten', 'buffalo@go.com', '21abb4bd519369d615d5155de2efb586d02de051005d1937bf9749dc41f6a5b8', 0),
(3, 'bill', 'digger@gmail.com', '623210167553939c87ed8c5f2bfe0b3e0684e12c3a3dd2513613c4e67263b5a1', 0),
(4, 'mary', 'elephant@wcupa.edu', '6915771be1c5aa0c886870b6951b03d7eafc121fea0e80a5ea83beb7c449f4ec', 0),
(5, 'joan', 'kangaroo@upenn.edu', 'd2dae6d1b4625413eade8cafcb06d6d000fdb57d963fc3c5c497084d42288319', 0),
(6, 'alice', 'feline@yahoo.com', '2bd806c97f0e00af1a1fc3328fa763a9269723c8db8fac4f93af71db186d6e90', 0),
(7, 'carla', 'badger@esu.edu', '8813d406421e0063ef8ec81fc45170338b4cfd9547ee1ab157b90b46bcb6e2a7', 1),
(8, 'dave', 'warthog@temple.edu', '61ea0803f8853523b777d414ace3130cd4d3f92de2cd7ff8695c337d79c2eeee', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `book_id` (`book_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrow`
--
ALTER TABLE `borrow`
  ADD CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`),
  ADD CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
