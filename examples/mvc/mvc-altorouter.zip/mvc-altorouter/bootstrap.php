<?php

require 'vendor/autoload.php';
require 'src/functions.php';

define('VIEWS_DIR', __DIR__ . '/src/views');

$databaseManager = new Illuminate\Database\Capsule\Manager();
$databaseManager->addConnection([
	'driver'    => 'mysql',
	'host'      => 'localhost',
	'database'  => 'library',
	'username'  => 'root',
	'password'  => 'root',
]);

$databaseManager->setAsGlobal();
$databaseManager->bootEloquent();
