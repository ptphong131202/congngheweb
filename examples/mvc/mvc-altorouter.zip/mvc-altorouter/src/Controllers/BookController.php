<?php

namespace App\Controllers;

use App\Models\Book;

class BookController
{
	public function index()
	{
		render_view('books', [
			'books' => Book::all()
		]);
	}

	public function find($id)
	{
		render_view('book', [
			'book' => Book::find($id)
		]);
	}
}
