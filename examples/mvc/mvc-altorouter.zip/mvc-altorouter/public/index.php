<?php

require __DIR__ . '/../bootstrap.php';

$router = new AltoRouter();

$router->map(
	'GET',
	'/',
	[App\Controllers\BookController::class, 'index'],
);

$router->map(
	'GET',
	'/books',
	[App\Controllers\BookController::class, 'index'],
	'books.show'
);

$router->map(
	'GET',
	'/books/[i:id]',
	[App\Controllers\BookController::class, 'find'],
	'books.findById'
);

$router->map(
	'GET',
	'/routes',
	function () use ($router) {
		$routes = $router->getRoutes();
		echo '<pre>';
		foreach ($routes as $route) {
			echo $route[1] . "\n";
		}
	},
	'routes.show'
);

$match = $router->match();

if ($match === false) {
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
	exit('404 Not Found');
}

if (is_callable($match['target'])) {
	call_user_func_array($match['target'], $match['params']);
} else if (is_array($match['target'])) {
	$controller = new $match['target'][0];
	$action = $match['target'][1];
	if (is_callable([$controller, $action])) {
		call_user_func_array([$controller, $action], $match['params']);
	} else {
		header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error');
		exit('500 Internal Server Error');
	}
}
